Ultimate Settings Panel
Version 1.0
24 August 2014
Instructions: http://www.techygeekshome.co.uk/2014/08/usp.html
===========================================================================================

Windows Tab
===========

Accessibility Options - Launches the management utility (Windows XP Only)
Action Center - Launches the management utility
Add New Hardware - Launches the management utility (Windows XP Only)
Administration Tools - Launches the management utility
AutoPlay - Launches the management utility
Bit Locker - Launches the management utility (Professional Operating Systems and above only)
Bluetooth Devices - Launches the management utility
Color Management - Launches the management utility
Credential Manager - Launches the management utility
Default Programs - Launches the management utility
Device Manager - Launches the management utility
Devices and Printers - Launches the management utility
Find Fast - Launches the management utility
Fonts - Launches the management utility
Game Controllers - Launches the management utility
God Mode - Creates the God Mode folder in C:\TGH and launches the program
Infrared - Launches the management utility
Internet Properties - Launches the management utility
Keyboard - Launches the management utility
Location Information - Launches the management utility
Mail Setup - Launches the management utility (only when Office/Outlook is installed)
Modem - Launches the management utility
Mouse - Launches the management utility
Network Connections - Launches the management utility
PC Card - Launches the management utility
People Near Me - Launches the management utility (Windows XP Only)
Power Configuration - Launches the management utility
Programs and Features - Launches the management utility
Region and Language - Launches the management utility
Remote Desktop - Launches the Remote Desktop Connection utility
Scanners and Cameras - Launches the management utility
Screen Resolution - Launches the management utility
Sound - Launches the management utility
System Properties - Launches the management utility
Tablet PC - Launches the management utility
Task Scheduler - Launches the management utility
Time and Date - Launches the management utility
Users Accounts - Launches the management utility
Windows Firewall - Launches the management utility
Windows Update - Launches the management utility

General Tab
===========

Add Features Win 8.1 - Launches the Windows 8.1 Add Features Wizard
Anytime Upgrade - Launches the Windows Anytime Upgrade Wizard
Control Panel - Launches the Windows Control Panel
Dekstop Gadgets - Launches the Windows Desktop Gadgets Management Utility
Family Safety - Launches the management utility
File History - Launches the management utility
File Recovery - Launches the management utility
Folder Options - Launches the management utility
Get Programs - Launches the management utility
Getting Started - Launches the management utility
HomeGroup - Launches the management utility
Indexing Options - Launches the management utility
Intel Graphics - Launches the management utility
iSCSi Initiator - Launches the management utility
Mobility Center - Launches the management utility
Network and Sharing - Launches the Network and Sharing Center
Network Setup - Launches the management utility
Notification Icons - Launches the Notification Icons Area Utility
ODBC Admin - Launches the ODBC Administration Utilty (Windows XP Only)
Offline Files - Launches the Offline Files Utility
Parental Controls - Launches the management utility
Performance Info - Launches the management utility
Problem Reports - Launches the management utility
Recovery - Launches the management utility
Security Center - Launches the management utility
Sync Center - Launches the management utility
Task Manager - Launches the Windows Task Manager
Text to Speak - Launches the management utility
Troubleshooting - Launches the management utility
Welcome Center - Launches the management utility
Windows CardSpace - Launches the management utility
Windows Defender - Launches the management utility
Windows Explorer - Launches the management utility
Windows Sideshow - Launches the management utility

Outlook 2010 Tab
===============

Please note that this program assumes that you have your Office 2010 installed at the following location:

%programfiles%\microsoft office\office14\

Clean Auto Complete - Removes all names and e-mail addresses from the Auto-Complete list
Clean Categories - Deletes any custom category names that you have created. Restores categories to the default names
Clean From Addresses - Removes all manually added From entries from the profile
Clean Reminders - Clears and regenerates reminders
Clean Sharing - Removes all RSS, Internet Calendar, and SharePoint subscriptions from Account Settings, but leaves all the previously downloaded content on your computer. This is useful if you cannot delete one of these subscriptions within Outlook 2010
Restore all Views - Restores default views. All custom views that you created are lost.
Reset Folders - Restores missing folders at the default delivery location
Reset Folder Names - Resets default folder names (such as Inbox or Sent Items) to default names in the current Office user interface language.
For example, if you first connect to your mailbox in Outlook by using a Russian user interface, the Russian default folder names cannot be renamed. To change the default folder names to another language, such as Japanese or English, you can use this switch to reset the default folder names after you change the user interface language or install a different language version of Outlook
Repair PST - Runs the Repair PST tool

ConfigMgr 2007 Tab
==================

Client Applet - Launches the Configuration Manager Control Panel Applet
Program Download Monitor - Launches the Program Download Monitor Utility
Run Advertised Programs - Launches the Run Advertised Programs Utility
Uninstall Client - Uninstalls the Configuration Manager Client

ConfigMgr 2012 Tab
==================

Please note that this program assumes that you have Configuration Manager Tools SP1 installed at the following location:

%programfiles%\Configmgr 2012 Toolkit SP1\ClientTools

Client Applet - Launches the Configuration Manager Control Panel Applet
CMTrace - Launches the CMTrace log file reader utility
Software Center - Launches the Software Center
Uninstall Client - Uninstalls the Configuration Manager Client 