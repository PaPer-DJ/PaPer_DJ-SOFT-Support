Unzipping the Stargate SG1 WinAmp skin.

Using WinZip (preferred).
Unzip the contents of the zip file into your WinAmp/Skins directory.
WinZip will create a new directory automatically for you and unzip 
the contents for you.


