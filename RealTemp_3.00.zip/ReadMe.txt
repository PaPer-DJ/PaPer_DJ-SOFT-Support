Documentation and support is available at:

http://www.techpowerup.com/realtemp
http://www.xtremesystems.org/forums/showthread.php?p=2809778#post2809778
