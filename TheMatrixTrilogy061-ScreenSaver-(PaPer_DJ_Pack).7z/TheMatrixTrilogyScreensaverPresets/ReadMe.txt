/// The Matrix Trilogy Screensaver presets
	by cresun ///
---------------------------------
>> INTRODUCTION
---------------------------------
	Thanks for downloading this preset pack for The Matrix Trilogy
	Screensaver.

	This package features 11 presets to use in The Matrix Trilogy
	Screensaver for Windows.

	Please see Acknowledgements below for more information.
---------------------------------
>> HOW TO INSTALL
---------------------------------
	1) Extract the preset files to any desired location

	2) Open the screensaver's configurations window and click
	   'Import preset' from the Presets tab

	3) Locate the preset files and import each file one by one

	4) Double-click on a preset name to activate it
---------------------------------
>> ACKNOWLEDGEMENTS
---------------------------------
	The Matrix Trilogy Screensaver is copyright by Jan Ringo�.
	I am not associated with the developer or the product.

	The Matrix Trilogy Screensaver website:
		http://www.thematrixscreensaver.com/
---------------------------------
>> TIME OF WRITING
---------------------------------
	This ReadMe was written on July 19, 2016.

		cresun