**********************************************************************
*  FTP Rush Readme File
*
*  Copyright (c) 2002-2010 Wing FTP Software, All rights reserved
*  E-mail: support@wftpserver.com
*  Web: http://www.wftpserver.com
**********************************************************************


Files :
-------
 Readme.txt			This file
 FtpRush.exe			Main execute file
 RushCmd.xml			FTP command file
 RushIcon.dll			Graphic resource dll
 RushSrpt.prt			Auto complete list for script IDE
 UpdRush.exe			Liveupdate program
 UnRAR.exe			File to unpack new version file
 
 Language\
   English.lng			English language file
   Simplified Chinese.lng	Simplified Chinese language file
   German.lng			Germany language file

Files genarated by FTPRush :
----------------------------
 RushBar.ini			Store the toolbar position and style
 RushCfg.xml			Store FTPRush personal setting
 RushDock.ini			Store the dockpanel position and style
 RushHist.ini			Store the history items for search/find etc
 RushPost.ini			Store position of some FTPRush window
 RushStyl.ini			Store the style and layout setting
 RushSite.xml			Store FTP favorites information
 RushTask.xml			Store Task information

Acknowledgment :
----------------
 (1) Synapse			http://www.ararat.cz/synapse
 (2) Contains "MD5 Message-Digest Algorithm" from RSA Data Security Inc.
 (3) TRegExpr class library by Andrey V. Sorokin (http://RegExpStudio.com)
 (4) RecyclerMM			Eric Grange
 (5) UnRAR.exe			UnRAR.exe from RARLab(WINRAR http://www.rarlab.com)
 (6) OpenSSL			www.openssl.org
 (7) Indy			http://www.nevrona.com/Indy/
 (8) THKStreams			Harry Kakoulidis (http://www.xarka.com/prog/)

Language File :
---------------
  Arabic			Awadh A		(1.1.Final 15)
  Brazilian Portuguese		alk		(1.0 Final 0591)
  Bulgarian			nerdix		(1.0 RC6 0565)
  Czech				cerda		(1.0.Final 0611)
  Danish			Reloaded	(1.0.Final 0606)
  Dutch				TFD		(1.0 Final 0610)
  English			IoRush Software	( Official )
  Finnish			wacky		(1.0 Final 0596)
  French			Jacques		(1.1 Final)
  German			Fizzz		(l.0.Final 0610)
  Hungarian			dy		(1.1 Final 15)
  Italian			r0kk0		(1.0.RC6 0557)
  Korean			Yellow.B	(1.0.Final 0623)
  Polish			Esmandil	(1.0 RC6 0557)
  Russian			Viktoras	(1.1a)
  Simplified Chinese		IoRush Software	( Official )
  Slovak			Alex		(1.0.RC5 0533)
  Spanish			nano		(1.0.RC6 0557)
  Swedish			Kenny		(1.0.RC5 0507)
  Traditional Chinese		zonghan		(1.0.Final 0614)
  Ukrainian			Victor		(1.0.RC5 0551)


  
Legend of version history :
---------------------------
  [+]	this is a new feature
  [*]	this is an improvement
  [!]	this is a change
  [x]	this is a bug fix


History:
--------

 Version 2.1.8     Released: 3/Nov/2011
  [x] Fixed bugs when using single connection mode
  [x] Fixed a bug - some issue when you specify "Local Path" for a site
  [x] Fixed a bug - incorrect display of directory list when transfer is completed
  [x] Fixed a bug - can't resume download sometimes



 Version 2.1.6     Released: 24/Oct/2011
  [x] Fixed queues can not be deleted when connetions broke
 


 Version 2.1.5     Released: 10/May/2011
  [x] Fixed queue can not restart after connetion interrupt recovery
  [x] Fixed can not close connection tab
  [x] Fixed do not show tab icon correctly 


 Version 2.1.4     Released: 26/Jan/2011
  [x] Fixed site download/upload limits reset to 2 when restart ftprush
  [+] Added Turkish language file
  [x] Updated Arabic language file
  [x] Updated German language file


 Version 2.1.3 	   Released: 21/Jan/2011
  [+] Added a option "Single connection mode"
  [+] Added limits for max download and upload logins    
  [x] Fixed can not check new version 
  [x] Fixed failed transfers do not disappear from queue
  [x] Fixed can not resume or delete queue when transfer connection is lost
  [x] Fixed can not download linux symbolic links
  [x] Fixed activity arrows on the tabs do not show correctly

 Version 2.1.2     Released: 21/Oct/2010 
  [x] Fixed can not transfer utf8 filename with SSH connection
  [x] Fixed do not show progress correctly when resume a SSH transfer
  [x] Fixed can not auto disconnect after transfer
  [x] Fixed can not show some special local directory under Windows 7	
  [x] Fixed can not restart transfer when transfer connection idle timeout

 Version 2.1.1     Released: 14/Oct/2010           
  [+] Added a option "Login with Utf-8 Username"
  [+] Added a portable version
  [*] Improved SSH download speed
  [*] Improved scripts support
  [x] Do not clear queue window when transfer finished
  [x] Do not refresh local file size when transfer finished
  [!] Updated Arabic language

 Version 2.1.0     Released: 5/Oct/2010
  [+] simultaneous transfer limit per site
  [+] public key authentication for SSH connection
  [x] Fixed random freeze window issue
  [x] Fixed random crash issue
  [x] Can not transfer 0 byte files by SSH connection
  [x] Can not sort queue by progress
  [x] Tray icon animation do not start
  
 Version 2.0.1 beta
  [+] Single connection mode (just set simultaneous transfers to 0) 
  [+] Queue time and Elapsed time
  [x] Crash issue when exit FTP Rush
  [x] Can not show Chinese file name with SSH connection
  [x] Can not change progress bar color
  

 Version 2.0.0 beta
  [+] Added support for  simultaneous transfer
  [x] Fixed SFV checking bug
  [x] Fixed user can not log in some FTP Server with Chinese username
  [x] Fixed SSH connection issue with some FTP Server
  [x] Fixed GUI issue under Windows 7
  

 Version 1.1.3
  [x] Fixed layout issue
  [x] Fixed SSL Connection with Wing FTP Server

 Version 1.1.2.19
  [x] Fixed SFV checking

 Version 1.1.2.18
  [+] updrush.exe updated, recommend upgrading it
  [x] Fixed downloading failed when the folder name including space

 Version 1.1.2.17
  [x] Fixed Native theme painting in Vista
  [x] Fixed Resize dock window with flicking

 Version 1.1.1.16
  [x] flicking when resize window

 Version 1.1.0.16
  [x] when wakeup a queueitem may break the transfer

 Version 1.1.0.15
  [*] Added a rushuser.lib to load default user data when first run
  [x] Fixed a waiting queue bug since 1.1.0.12
 
 Version 1.1.0.12
  [x] Fixed high CPU usage when ftp.transfer be called
  [*] RushApp.DeleteEmptyContainers renamed to RushApp.DeleteEmptyTabs
  [*] flag RS_DELEMPTYTAB changed to RS_DELEMPTYTABS

 Version 1.1.0.11
  [*] Better/Fast arithmetic for waiting queues

 Version 1.1.0.10
  [x] AV errors when exit ftprush with transferring

 Version 1.1.0.9
  [+] New flag: RS_DELEMPTYTAB for RushApp.FTP.Transfer
  [x] Since 1.0.0625 some unicode features broken
  [*] Improved GUI kernel

 Version 1.1.0.8
  [+] new function: RushApp.DeleteEmptyContainers

 Version 1.1.0.7
  [x] Fixed "out of range" error in script

 Version 1.1.0.6
  [x] Fixed Containers object in script

 Version 1.1.0.5
  [+] Allow bypass proxy on datachannel(site properties/connection/proxy server)
  [x] Check_Login do not set QueueItem as standby status anymore

 Version 1.1.0.4
  [*] kernel improvements
  [*] Script engine improvements
  [*] Compiled script file extension changed to ".pc0"
  [*] Memory Manager improvements

 Version 1.1.0.3
  [x]Fixed UPnP with Tomato Firmware
  [x]Fixed UPnP when Router use static/dhcp IP
  [x]Fixed "STAT -l" with new glFTPD

 Version 1.0.0.626
  [x] Fixed bug when resume upload/download > 2gb file
  [x] Fixed bug when check new version automatically

 Version 1.0.0.625
  [+] RushApp.FTP.EnableSite(Sitename:string;ThisSession:boolean);
  [+] RushApp.FTP.DisableSite(Sitename:string;ThisSession:boolean);

 Version 1.0.0.624
  [x] Fixed MLSD attributes with Unix.Mode string

 Version 1.0.0.623
  [*] Now uploading file will update file datetime always
  [x] Fixed a MDTM Command bug
  [x] "Modify date of FTP files" now use FTP Server TimeZone automatically

 Version 1.0.0.622
  [*] Improved Lock/Unlock Toolbar/Dock actions

 Version 1.0.0.621
  [*] LiveUpdate now is for registered user only
  [x] Quick connect to a ftp with port 22 now do not use sftp protocol
  [x] Wrong GUI painting in Vista with Office 11 style
  [x] Wrong Version checking when liveupdate  

 Version 1.0.0.620
  [x] when XCRC enabled, do not use sfv checking anymore

 Version 1.0.0.619
  [x] Do not try to get ftp file time when View File
  [x] Do not try to get ftp file xcrc when View File

 Version 1.0.0.618
  [x] SSL FXP disabled after a Non-SSL FXP transfer

 Version 1.0.0.617
  [x] Do not create "my ftprush downloads" when default download path exists
  [x] Fixed auto detect resume mode when server do not support resume ASCII files

 Version 1.0.0.616
  [*] FTPRush.exe signed with digital certificate
  [x] Proxy Form did not saved anonymous information

 Version 1.0.0.615
  [*] Improved Vista Compatibility of the installer
  [*] minor changes with GUI kernel
  [x] CRC thread returns error when file is in use

 Version 1.0.0.614
  [x] Fixed a bug in Listview

 Version 1.0.0.613
  [x] CompleteFlag now do not skip files/folders

 Version 1.0.0.612
  [+] Add "PortableData=1" to "License" section from ftprush.ini, Load setting from current folder
  [x] A bug when restore from trayicon

 Version 1.0.0.611
  [*] Improved compatibility of HTTP Tunnel Proxy
  [x] Do not force upgrading to new version
  [x] Use old version protection method

 Version 1.0.0.610
  [x] Fixed a multithreaded dead lock bug
  [x] Wrong shell icons in Vista
  [x] Can not remove license key from about dialog

 Version 1.0.0.609
  [x] Queue window lost selection after moved items

 Version 1.0.0.608
  [+] new confirm option: "when delete queue file" (option/confirm)
  [*] use ftprush.exe -f param if you want to load the setting from installed dir
  [*] improves uploading speed

 Version 1.0.0.607
  [x] Lost shell icons when C: partition not exists

 Version 1.0.0.606
  [x] skip "zero file file" not working if filename match site allowlist

 Version 1.0.0.605
  [x] The PRET STOR command did not sent when PASV mode
  [x] Fixed a bug when import plain format skiplist file

 Version 1.0.0.604
  [+] %W% added to skip/allow mask, means matching full path
  [+] New skiplist, supporting matching full path, and split upload/download/fxp
  [x] did not saved "use skiplist" of per site 
  [x] Some wrong actions with skiplist/allowlist

 Version 1.0.0.603
  [x] Wrong folder/file icons when list some ftp server with Unix directory style

 Version 1.0.0.602
  [x] AV errors when click "apply" in option dialog
  [x] Now do not sent "PRET STOR" when uploading and FTP is active mode

 Version 1.0.0.601
  [*] improved the -r commandline, with 'x','t' attributes. check help file for details
  [x] Now UPnP works with multiple NIC card.

 Version 1.0.0.600
  [+] commandline: ftprush.exe -r, run all queue when startup and minimize to tray; Licensed version only
