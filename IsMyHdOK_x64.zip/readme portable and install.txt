By default, the IsMyHdOK.ini will be created in the folder %APPDATA%/IsMyHdOK
For portable use, please create or copy in IsMyHdOK working directory the IsMyHdOK.ini.



 